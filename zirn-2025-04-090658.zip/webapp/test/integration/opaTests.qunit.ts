/* global QUnit */

sap.ui.require(["integration/NavigationJourney"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});